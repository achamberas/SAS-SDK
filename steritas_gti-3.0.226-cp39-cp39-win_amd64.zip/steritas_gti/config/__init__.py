import yaml
from pkg_resources import resource_filename


def __read_settings():
    try:
        with open(resource_filename(__name__, "config.yaml"), "r") as file:
            return yaml.safe_load(file)
    except Exception as e:
        print(e)
        return {}


SETTINGS = __read_settings()
